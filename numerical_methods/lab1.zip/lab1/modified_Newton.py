import math

class ModifiedNewton:
    def __init__(self, f, df, d2f, x0, eps=1e-6, max_iter=100):
        self.f = f
        self.df = df
        self.d2f = d2f
        self.x0 = x0
        self.eps = eps
        self.max_iter = max_iter
        self.history = []

    def check_theoretical_q(self, a, b):
        xs = [a + i * (b - a) / 1000 for i in range(1001)]
        M2 = max(abs(self.d2f(x)) for x in xs)
        m1_candidates = [abs(self.df(x)) for x in xs if abs(self.df(x)) > 1e-12]
        if not m1_candidates:
            raise ValueError("Похідна f'(x) майже нуль на всьому інтервалі")
        m1 = min(m1_candidates)

        q = M2 / (2 * m1) * abs(self.x0 - self.root if self.root is not None else 0.0)
        if self.f(self.x0) * self.d2f(self.x0) <= 0:
            raise ValueError("Умова f(x0) * f''(x0) > 0 не виконана")
        if q >= 1:
            raise ValueError(f"Теоретичний q >= 1 ({q:.4f}) — збіжність не гарантована")
        self.q = q

    def check_conditions(self, a, b):
        f0 = self.f(self.x0)
        d2f0 = self.d2f(self.x0)

        if f0 * d2f0 <= 0:
            print("умова f(x0)*f''(x0) > 0 не виконується — метод може розбігтись.")

        # Оцінка M2 і m1 на відрізку [a, b]
        xs = [a + i*(b - a)/100 for i in range(101)]
        M2 = max(abs(self.d2f(x)) for x in xs)
        m1 = min(abs(self.df(x)) for x in xs if self.df(x) != 0)

        # Оцінка q
        q = (M2 * abs(self.x0 - (a + b) / 2)) / (2 * m1)
        if q >= 1:
            print(f"q = {q:.3f} ≥ 1 → можлива розбіжність методу.")
        else:
            print(f"Умова збіжності виконується: q = {q:.3f} < 1")

    def solve(self, a, b):
        self.check_conditions(a, b)

        x = self.x0
        for i in range(self.max_iter):
            fx = self.f(x)
            dfx = self.df(x)
            d2fx = self.d2f(x)

            if abs(dfx) < 1e-10:
                raise ZeroDivisionError("f'(x) ≈ 0 — ризик розбігання методу.")

            x_new = x - (fx / self.df(self.x0))

            # Перевірка виходу за межі
            if not (a <= x_new <= b):
                raise ValueError(f"x_new вийшов за межі допустимого діапазону: {x_new}")

            self.history.append(x_new)

            if abs(x_new - x) < self.eps:
                print(f" Збіжність досягнута за {i+1} ітерацій")
                return x_new

            x = x_new

        print("досягнуто максимум ітерацій без збіжності.")
        return x

    def __str__(self):
        if self.root is None:
            return "Метод ще не виконано."

        q_str = f"{self.q:.4f}" if self.q is not None else "N/A"
        return (
            f"Модифікований метод Ньютона:\n"
            f" Початкове наближення: {self.x0:.4f}\n"
            f" Корінь: {self.root:.8f}\n"
            f" f(root) = {self.f(self.root):.6e}\n"
            f" Ітерацій: {self.iterations}\n"
            f" q (теоретичний) ≈ {q_str}"
        )
