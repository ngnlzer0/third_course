import math

class dichotomy_method():
    def __init__(self,func,a,b, eps = 1e-4, max_iter = 1000):
        self.f = func
        self.a = a
        self.b = b
        self.eps = eps
        self.max_iter = max_iter
        self.root = None
        self.iterations = 0

    def solve(self):
        a, b = self.a, self.b
        fa, fb = self.f(a), self.f(b)

        if fa * fb > 0:
            raise ValueError("На відрізку [{}, {}] немає зміни знаку.".format(a, b))

        it = 0

        while (b - a) / 2 > self.eps and it < self.max_iter:
            c = (a + b) / 2
            fc = self.f(c)
            if c == 0:
                a = b = c
                break
            if fa * fc < 0:
                b = c
                fb = fc
            else:
                a = c
                fa = fc
            it += 1

        self.root = (a + b) / 2
        self.iterations = it

        return self.root

    def apriori_estimate(self):
        return math.ceil(math.log2((self.b - self.a) / self.eps))

    def __str__(self):
        return (f"Метод Дихтомії:\n"
                f"  Інтервал: [{self.a:.4f}, {self.b:.4f}]\n"
                f"  Корінь: {self.root:.8f}\n"
                f"  f(root) = {self.f(self.root):.6e}\n"
                f"  апостеріорна оцінка : {self.iterations}\n"
                f"  Апріорна оцінка: {self.apriori_estimate()}\n")

